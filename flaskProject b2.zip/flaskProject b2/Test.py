from ultralytics import YOLO
from flask import Flask, request, abort, send_from_directory, jsonify, session, render_template

import numpy as np

import glob
from utils.flask_utils import *


model = YOLO("./models/ebike.pt")
def predict_image(file_save_path):
    # 对图像进行预测
    results = model.predict(source=file_save_path, save=True, device=0)
    return results


predict_image('save/pic6.png')
