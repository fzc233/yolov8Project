document.getElementById('imageUpload').addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.createElement('img');
            img.src = e.target.result;
            const originalImageBox = document.getElementById('originalImageBox');
            originalImageBox.innerHTML = ''; // 清空原图片区域
            originalImageBox.appendChild(img); // 添加新图片
        };
        reader.readAsDataURL(file); // 读取文件作为 URL
    }
});

document.getElementById('processBtn').addEventListener('click', function() {
    const formData = new FormData();
    const imageFile = document.getElementById('imageUpload').files[0];
    if (!imageFile) {
        alert('请先上传图片！');
        return;
    }
    formData.append('image', imageFile);

    fetch('/process-image', { // 确保后端有对应的 '/process-image' 路由处理图片
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const img = document.createElement('img');
        img.src = data.processedImageUrl; // 假设服务器返回处理后图片的 URL
        document.getElementById('processedImageBox').innerHTML = '';
        document.getElementById('processedImageBox').appendChild(img);
    })
    .catch(error => {
        console.error('Error:', error);
        alert('处理图片时发生错误');
    });
});
