document.addEventListener('DOMContentLoaded', function() {
    const modelSelect = document.getElementById('filterOption');
    const imageInput = document.getElementById('imageUpload');
    const submitButton = document.getElementById('submitButton');

    function updateSubmitButtonState() {
        submitButton.disabled = !modelSelect.value || imageInput.files.length === 0;
    }

    imageInput.addEventListener('change', function() {
        if (imageInput.files && imageInput.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const originalImageBox = document.getElementById('originalImageBox');
                originalImageBox.innerHTML = '<img src="' + e.target.result + '" alt="Image preview">';
            };
            reader.readAsDataURL(imageInput.files[0]);
        }
        updateSubmitButtonState();
    });

    modelSelect.addEventListener('change', updateSubmitButtonState);

    document.getElementById('modelAndImageForm').addEventListener('submit', function(event) {
        event.preventDefault();

        if (imageInput.files.length === 0 || !modelSelect.value) {
            alert('请选择模型并上传图片');
            return;
        }

        const formData = new FormData();
        formData.append('file', imageInput.files[0]);
        formData.append('filterOption', modelSelect.value);

        // 延迟提交
        setTimeout(() => {
            fetch('/recognize', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.data && data.data.after_img_path) {
                    const processedImageBox = document.getElementById('processedImageBox');
                    processedImageBox.innerHTML = '<img src="' + data.data.after_img_path + '" alt="Processed Image">';
                } else {
                    alert('图片处理失败');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('处理图片时发生错误');
            });
        }, 2000); // 延迟 3 秒
    });
    //重置
    const resetButton = document.getElementById('resetButton');
    resetButton.addEventListener('click', function() {
        // 清除图片预览
        const originalImageBox = document.getElementById('originalImageBox');
        const processedImageBox = document.getElementById('processedImageBox');
        originalImageBox.innerHTML = '原图片';
        processedImageBox.innerHTML = '处理后的图片';

        // 重置表单
        const form = document.getElementById('modelAndImageForm');
        form.reset();

        // 重置提交按钮状态
        const submitButton = document.getElementById('submitButton');
        submitButton.disabled = true;
    });
});
