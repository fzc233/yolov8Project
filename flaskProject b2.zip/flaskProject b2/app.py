from ultralytics import YOLO
from flask import Flask, request, abort, send_from_directory, jsonify, session, render_template
from pprint import pprint
import numpy as np
import supervision as sv
from flask import Response
from utils.flask_utils import *
import base64

current_dir = os.getcwd()  # 获取当前文件夹的路径
BEFORE_IMG_PATH = os.path.join(current_dir, 'static', 'old')  # 存储上传前图片的路径
AFTER_IMG_PATH = os.path.join(current_dir, 'static', 'save')  # 存储处理后图片的路径


box_annotator = sv.BoxAnnotator(
    thickness=2,
    text_thickness=1,
    text_scale=0.5
)

model_files = {
    'evRecognition': "./models/ebike.pt",
    'maskRecognition': "./models/mask.pt",
    'dogRecognition': "./models/dog.pt"
}


app = Flask(__name__, static_folder='static')


@app.route("/photo", methods=["POST"])
def recognize_base64():
    photo_data = request.form.get('photo')  # 获取前端传递的 base64 图片数据
    photo_data = photo_data.replace('data:image/png;base64,', '')  # 去掉 base64 编码中的前缀

    # 解码 base64 数据为二进制数据
    image_data = base64.b64decode(photo_data)

    # 保存为文件
    before_img_path = save_img_base64(image_data, path=BEFORE_IMG_PATH)

    # 处理完成后，返回响应
    name = f"{''.join(random.choice(string.ascii_lowercase) for i in range(5))}.png"

    # 返回结果
    return yolo_res(before_img_path=before_img_path, name=name)

from flask import Response
import json

@app.route("/recognize", methods=["POST"])
def recognize_photo():
    photo = request.files['file']
    model_option = request.form.get('filterOption')

    if model_option not in model_files:
        abort(400, 'Invalid model option')

    # 加载相应的模型
    model = YOLO(model_files[model_option])

    name = photo.filename
    img = cv2.imdecode(np.fromstring(photo.read(), np.uint8), cv2.IMREAD_UNCHANGED)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

    before_img_path = save_img(name, img, BEFORE_IMG_PATH)

    # 使用模型处理图片并返回结果
    result = yolo_res(before_img_path=before_img_path, name=name, model=model)
    return Response(result, mimetype='application/json')



# yolo 处理图片
def yolo_res(before_img_path, name,model):
    try:
        img = Image.open(before_img_path)
        iter_model = iter(model.track(source=img, show=False))
        result = next(iter_model)

        detections = sv.Detections.from_yolov8(result)

        if result.boxes.id is None:
            return wrap_ok_return_value('照片中没有目标物体哟！')

        detections.tracker_id = result.boxes.id.cpu().numpy().astype(int)

        res_img = result.orig_img
        res_url = save_res_img(res_img, detections, name)

        labels = [
            f"OBJECT-ID: {tracker_id} CLASS: {model.model.names[class_id]} CF: {confidence:0.2f} x:{x} y:{y}"
            for x, y, confidence, class_id, tracker_id in detections
        ]

        return wrap_ok_return_value({
            'labels': labels,
            'after_img_path': res_url
        })
    except Exception as e:
        pprint(str(e))
        return wrap_error_return_value('服务器繁忙，请稍后再试！')

def save_res_img(res_img, detections, name = 'default.jpg'):

    labels = [
        f"ID: {tracker_id}"
        for x, y, confidence, class_id, tracker_id in detections
    ]

    img_box = box_annotator.annotate(scene=res_img, detections=detections, labels=labels)

    # 将 BGR 格式的 frame 转换为 RGB 格式
    rgb_frame = cv2.cvtColor(img_box, cv2.COLOR_BGR2RGB)

    # 把 rgb_frame 转换为 numpy格式 就行了
    numpy_frame = np.array(rgb_frame)

    after_img_path = os.path.join(AFTER_IMG_PATH, name)
    cv2.imwrite(after_img_path, numpy_frame)  # 保存图片

    # 使用字符串替换方法将文件路径转换为指定的 URL 格式
    return os.path.join('/static', 'save', name)
# 对图像进行预测

def save_img(name, img, path):
    img_path = os.path.join(path, name)
    cv2.imwrite(img_path, img)  # 保存图片
    return img_path

@app.route('/')
def index():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
