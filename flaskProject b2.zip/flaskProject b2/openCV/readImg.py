#导入cv
import cv2 as cv
#读取图片
img  = cv.imread('D:\\flaskProject\openCV\\test1.jpg')

if img is None:
    print("图像未成功加载，请检查文件路径和文件完整性")
else:
    # 现在可以安全地使用 cv2.cvtColor
    # 灰度转换
    grey_img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
#显示图片
cv.imshow('Gray',grey_img)
#保存灰度图片
cv.imwrite('gray.jpg', grey_img)
cv.imshow('img',img)
#等待
cv.waitKey(0)
#释放内存
cv.destroyAllWindows()