#导入cv
import cv2 as cv

def ebike_detect_demo():
    #把图片转换成灰度的
    gray=cv.cvtColor(img,cv.COLOR_BGR2GRAY)
    #加载分类器
    ebike_detect = cv.CascadeClassifier('')

#读取图片
img  = cv.imread('D:\\flaskProject\openCV\\test1.jpg')
#检测函数
ebike_detect_demo()
#等待
while True:
    if ord(' ') == cv.waitKey(0):
        break
#释放内存
cv.destroyAllWindows()