#导入cv
import cv2 as cv
#读取图片
img  = cv.imread('D:\\flaskProject\openCV\\test1.jpg')
#修改图片尺寸
reSize_img=cv.resize(img,dsize=(600,480))
#显示原图
cv.imshow('img',img)
#显示修改后的
cv.imshow('img2',reSize_img)
#打印各自大小
print("未修改，",img.shape)
print("未修改，",reSize_img.shape)

while True:
    if ord(' ') == cv.waitKey(0):
        break
#释放内存
cv.destroyAllWindows()